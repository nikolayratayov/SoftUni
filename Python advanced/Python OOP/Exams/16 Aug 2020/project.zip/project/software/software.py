class Software:
    def __init__(self, name, software_type, capacity_consumption, memory_consumption):
        self.name = str(name)
        self.software_type = str(software_type)
        self.capacity_consumption = int(capacity_consumption)
        self.memory_consumption = int(memory_consumption)

